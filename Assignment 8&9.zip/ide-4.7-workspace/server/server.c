#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/dispatch.h>
#include <sys/mman.h>

struct pid_data{
	pthread_mutex_t pid_mutex;
	pid_t pid;
};

int get_priority();
int set_priority(int priority);

int main(int argc, char *argv[]) {
	int fd, chid, rcvid;
	struct pid_data *shared_pid;
	pthread_mutexattr_t myattr;
	char buff[255];
	struct _msg_info msg_info;

	set_priority(21);

	//Without priotity inheritance
	chid = ChannelCreate(_NTO_CHF_FIXED_PRIORITY);

	//With priority inheritance
	//chid = ChannelCreate(0);

	fd = shm_open("/sharedpid", O_RDWR | O_CREAT, S_IRWXU);
	ftruncate(fd, sizeof(struct pid_data));
	shared_pid = mmap(0, sizeof(struct pid_data), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    pthread_mutexattr_init(&myattr);
    pthread_mutexattr_setpshared(&myattr, PTHREAD_PROCESS_SHARED);
    pthread_mutex_init(&shared_pid->pid_mutex, &myattr );

    pthread_mutex_lock(&shared_pid->pid_mutex);
    shared_pid->pid = getpid();
    printf("Shared mem. Pid: %i\n", shared_pid->pid);
    pthread_mutex_unlock(&shared_pid->pid_mutex);


    while(1) {
    	rcvid = MsgReceive(chid, buff, sizeof(buff), &msg_info);
    	printf("PID: %i TID: %i Priority: %i Msg: %s\n", msg_info.pid, msg_info.tid, get_priority(),buff);

    	MsgReply(rcvid, EOK, "EOK", sizeof("EOK"));
    }
	return EXIT_SUCCESS;
}


int get_priority()
{
	int policy;
	struct sched_param param;

	// get priority
	pthread_getschedparam(pthread_self(), &policy, &param);
	return param.sched_curpriority;
}

int set_priority(int priority)
{
     int     policy;
     struct sched_param param;
     // check priority in range
     if (priority < 1 || priority > 63) return -1;
     // set priority
     pthread_getschedparam(pthread_self(), &policy, &param);
     param.sched_priority = priority;
     return pthread_setschedparam(pthread_self(), policy, &param);
}
