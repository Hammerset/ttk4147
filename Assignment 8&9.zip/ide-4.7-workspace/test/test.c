#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
	printf("Welcome to the QNX Momentics IDE\n");
	return EXIT_SUCCESS;
}
