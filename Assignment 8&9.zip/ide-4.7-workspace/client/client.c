#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/dispatch.h>
#include <sys/mman.h>

#define NO_THREADS 4
#define NO_MSG_PR_THREAD 3

struct pid_data{
	pthread_mutex_t pid_mutex;
	pid_t pid;
};

void *threads(void *p);
int set_priority(int priority);
int get_priority();


int main(int argc, char *argv[]) {
	int i;
	int priority[NO_THREADS];
	pthread_t m_threads[NO_THREADS];

	set_priority(40);

	printf("Message server running.\n");

	//create threads
	for(i=0; i<NO_THREADS; i++) {
		priority[i] = 20+i;
		pthread_create(&m_threads[i], NULL, threads, (void*)priority[i]);
	}

	//waiting for threads
	for(i=0; i<NO_THREADS; i++) {
		pthread_join(m_threads[i],NULL);
	}

	return EXIT_SUCCESS;
}

void *threads(void *p) {
		int i;
		int priority = (int)p;
		int fd, chid, rcvid;
		struct pid_data *shared_pid;
		char recv_buff[255], send_buff[255];

		set_priority(priority);
		printf("Thread: %i, Priority: %i\n", pthread_self(), get_priority());

		fd = shm_open("/sharedpid", O_RDWR, S_IRWXU);
		shared_pid = mmap(0, sizeof(struct pid_data), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

	    pthread_mutex_lock(&shared_pid->pid_mutex);
	    printf("Thread %i connected to server witg PID: %i.\n", pthread_self(), shared_pid->pid);
	    chid = ConnectAttach(0, shared_pid->pid, 1, 0, 0);
	    pthread_mutex_unlock(&shared_pid->pid_mutex);

	    for(i=0; i<NO_MSG_PR_THREAD; i++) {
	    	sprintf(send_buff, "Hello %i", i);
	    	rcvid = MsgSend(chid, send_buff, sizeof(send_buff), recv_buff, sizeof(recv_buff));
	    	printf("Message from server: %s\n", recv_buff);
	    }
	    ConnectDetach(chid);


	    pthread_exit(NULL);
}


int set_priority(int priority)
{
     int     policy;
     struct sched_param param;
     // check priority in range
     if (priority < 1 || priority > 63) return -1;
     // set priority
     pthread_getschedparam(pthread_self(), &policy, &param);
     param.sched_priority = priority;
     return pthread_setschedparam(pthread_self(), policy, &param);
}
int get_priority()
{
     int     policy;
     struct sched_param param;
     // get priority
     pthread_getschedparam(pthread_self(), &policy, &param);
     return     param.sched_curpriority;
}
