#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]) {
	printf("Reading client\n");

	char buf[255];
	int fd;

	while(1) {
		fd = open("/dev/myresource", O_RDONLY);
		//fd = open("/dev/myresource", O_NONBLOCK);
		read(fd, buf, 255);
		close(fd);
		printf("Client read: %s \n ", buf);
		memset(buf, '\0', 255);
		delay(2500);
	}
	return EXIT_SUCCESS;
}
